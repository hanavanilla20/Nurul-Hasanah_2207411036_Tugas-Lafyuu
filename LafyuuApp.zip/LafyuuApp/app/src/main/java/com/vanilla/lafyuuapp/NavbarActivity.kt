package com.vanilla.lafyuuapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.vanilla.lafyuuapp.databinding.ActivityNavbarBinding

class NavbarActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNavbarBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNavbarBinding.inflate(layoutInflater)
        setContentView(binding.root)
        replaceFragment(HomeFragment())

        binding.bottomNavigationView.setOnClickListener{
            when(it.id) {
                R.id.HomeNav -> replaceFragment(HomeFragment())
                R.id.ExploreNav -> replaceFragment(ExploreFragment())
                R.id.CarteNav -> replaceFragment(CartFragment())
                R.id.OfferNav -> replaceFragment(OfferFragment())
                R.id.AccountNav -> replaceFragment(AccountFragment())

                else -> {

                }
            }
            true
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.FrameLayout, fragment)
        fragmentTransaction.commit()
    }
}